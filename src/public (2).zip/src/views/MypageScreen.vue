<template>
  <div class="profile">
    <div class="profile__icon">
      <img v-if="$store.state.photoURL" :src="photoURL" alt="" srcset="" class="profile__icon-image">
      <div v-else class="profile__icon-slot"> </div>
    </div>
    <div v-if="$store.state.username" class="profile__username">
      {{ $store.state.username }}
    </div>
    <div v-if="$store.state.uid" class="profile__uid">
      {{ $store.state.uid }}
    </div>
    <img class="profile__figure-cat" :src="figure_cat" alt="">
  </div>
  <div class="cardlist">
    <card class="card" v-for="event in events" :event="event" :key="event.id">
    </card>
  </div>
</template>
<script>
import card from "@/components/Postcard.vue";
import {
  getFirestore,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";

export default {
  name: "DashboardScreen",
  components: {
    card,
  },
  data() {
    return {
      events: [],
      photoURL: this.$store.state.photoURL,
      figure_cat: require("@/assets/img/prop/figure_cat.png"),
    };
  },
  mounted: function () {
    const db = getFirestore();
    const q = query(
      collection(db, "events"),
      where("user_id", "==", this.$store.state.uid)
    );
    getDocs(q)
      .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          this.events.push(doc.data());
          // doc.idを追加
          this.events[this.events.length - 1].id = doc.id;
        });
      })
      .catch((error) => {
        console.log("ドキュメント取得ミス: ", error);
      });
  },
};
</script>
<style lang="scss">
.profile {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 20px 40px;
  border-radius: 26px;
  background-color: #fff;
  border: 1px solid #ddbfec;

  &__icon {
    width: 80px;
    height: 80px;
    object-fit: contain;
    border-radius: 40px;
    overflow: hidden;
  }

  &__icon-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 40px;
    border: 1px solid #ddbfec;
  }

  &__icon-slot {
    width: 100%;
    height: 100%;
    border-radius: 40px;
    border: 1px dashed #ddbfec;
  }

  &__username {
    font-size: 18px;
    font-weight: bold;
  }

  &__uid {
    font-size: 12px;
  }

  &__figure-cat {
    width: 160px;
    height: 160px;
    object-fit: contain;
    position: absolute;
    top: -20px;
    right: -40px;
    animation: rotate 80s linear infinite;
  }

  @keyframes rotate {
    0% {
      transform: rotate(0deg);
    }

    100% {
      transform: rotate(360deg);
    }
  }
}

.cardlist {
  display: flex;
  flex-direction: column;
  gap: 10px;
  overflow: auto hidden;
  padding-bottom: 10px;
}
</style>
