<template>
  <div class="create-post" :class="classObject">
    <!-- 送信ボタン -->
    <textarea class="create-post__textarea" v-model="description" placeholder="いまなにしてる？"></textarea>
    <input class="create-post__mediafile" type="file" @change="onChangeImage" />
    <img class="create-post__preview" v-if="img_url" :src="img_url" />
    <button class="create-post__submit" @click="createEvent">送信</button>
    {{ storagePath }}
  </div>
  <div class="modal-background" @click="closeModal" :class="classObject"></div>
</template>

<script>
import { ref } from "vue";
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  updateDoc,
} from "firebase/firestore";

const date = ref(new Date());
export default {
  name: "CreatePostScreen",
  props: {
    isModalOpen: Boolean,
  },
  data() {
    return {
      uid: this.$store.state.uid,
      description: "",
      img_url: "",
      storagePath: "",
      file: null,

    };
  },
  setup() {
    const title = ref("");
    return {
      title,
      date,
    };
  },
  methods: {
    onChangeImage(e) {
      const files = e.target.files;
      if (files.length > 0) {
        this.file = files[0];
        this.img_url = URL.createObjectURL(files[0]);
      }
    },
    async createEvent() {
      const db = getFirestore();
      console.log("Firestore Database Reference:", db);

      // step1
      const eventCollectionRef = collection(db, "events");
      const eventDocRef = doc(eventCollectionRef);
      // データ構造
      const event = {
        user_id: this.uid,
        desc: this.description,
      };

      console.log(event);

      // setDoc メソッドを使用
      await setDoc(eventDocRef, event);

      // step2
      const eventId = eventDocRef.id;

      // step3
      if (this.file) {
        this.storagePath = await this.uploadImage(
          this.file,
          "event/" + eventId + "/"
        );
      }

      // step4
      await updateDoc(eventDocRef, {
        img_url: this.storagePath,
      });

      alert("投稿を作成しました:" + this.uid);
      // VueDatePickerをクリア
      this.date = null;

      this.$router.push("/");
    },
    closeModal() {
      this.$emit("closeModal");
    },
  },
  computed: {
    classObject() {
      return {
        "modal-open": this.isModalOpen,
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.modal-background {
  z-index: 100;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #6666;
  backdrop-filter: blur(4px);
  z-index: -1;
  opacity: 0;
  transition: 0.5s;

  &.modal-open {
    z-index: 999;
    opacity: 1;
  }
}

.create-post {
  z-index: 1000;
  position: absolute;
  top: 50%;
  top: 110vh;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  padding: 40px;
  border-radius: 40px;
  border: 1px solid #c370ca;
  transition: top 0.6s cubic-bezier(0.25, 1, 0.5, 1);

  &.modal-open {
    top: 50%;
    transition: top 0.6s cubic-bezier(0.25, 1, 0.5, 1);
  }

  &:after {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(calc(-50% + 10px), calc(-50% + 10px));
    content: "";
    width: 100%;
    height: 100%;
    border-radius: 40px;
    background-color: #fff6;
    border: 1px solid #c370ca;
    z-index: -1;
  }

  &__textarea {
    resize: none;
    width: 100%;
    height: 140px;
    margin-bottom: 24px;
  }
}
</style>
