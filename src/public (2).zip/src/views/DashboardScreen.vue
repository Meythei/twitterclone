<template>
  <div class="dashboard">
    <div class="dashboard__acc-button dashboard__acc-button--01"></div>
    <div class="dashboard__acc-button dashboard__acc-button--02"></div>
    <div class="dashboard__inner">
      <div class="dashboard__acc-camera"></div>
      <h1 class="dashboard__heading">ホーム</h1>
      <div class="dashboard__cardlist" v-if="!events.length == 0">
        <card v-for="event in events" :event="event" :key="event.id" :glass="true">
        </card>
      </div>
      <!-- ポストがない場合 -->
      <div v-else>ポストがありません</div>
    </div>
  </div>
</template>

<script>
import card from "@/components/Postcard.vue";
import { getFirestore, collection, query, getDocs } from "firebase/firestore";

export default {
  name: "DashboardScreen",
  components: {
    card,
  },
  data() {
    return {
      events: [],
    };
  },
  mounted: function () {
    const db = getFirestore();
    const q = query(collection(db, "events"));
    getDocs(q)
      .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          this.events.push(doc.data());
          // doc.idを追加
          this.events[this.events.length - 1].id = doc.id;
        });
      })
      .catch((error) => {
        console.log("ドキュメント取得ミス: ", error);
      });
  },
  methods: {
    formatDate(timestamp) {
      const date = new Date(timestamp.seconds * 1000);
      return date.toLocaleDateString("ja-JP", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      });
    },
  },
};
</script>

<style lang="scss">
.dashboard {
  position: relative;
  border-radius: 40px;
  border: 1px solid #BD91B9;
  background: #FEFBFF;
  padding: 4px;

  &__inner {
    position: relative;
    border-radius: 36px;
    background-color: #fff;
    border: 1px solid #BD91B9;
    display: flex;
    flex-direction: column;
    height: 90vh;
  }

  &__acc-button {
    position: absolute;
    right: -6px;
    width: 6px;
    border-radius: 0 4px 4px 0;
    background: #DABCEE;
    border: 1px solid #C370CA;

    &--01 {
      top: 120px;
      height: 70px;
    }

    &--02 {
      top: 200px;
      height: 100px;
    }
  }

  &__acc-camera {
    width: 30%;
    height: 16px;
    margin: 10px auto 0px;
    border-radius: 20px;
    border: 1px solid #C370CA;
    background: #F1DBFC;
  }

  &__heading {
    border-radius: 36px 36px 0 0;
    background-color: #fff;
    border-bottom: 1px solid #BD91B9;
    font-size: 24px;
    font-weight: bold;
    padding: 12px 0 12px 12px;
  }

  &__cardlist {
    flex: 1;
    overflow: visible auto;
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding-top: 12px;
    width: calc(100% + 20px);
    border-radius: 0 0 36px 36px;
    left: -10px;
    position: relative;
    -ms-overflow-style: none;
    scrollbar-width: none;

    &::-webkit-scrollbar {
      display: none;
    }

  }
}
</style>