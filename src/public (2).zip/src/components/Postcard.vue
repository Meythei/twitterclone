<template>
  <a class="card" :class="classObject" v-bind:href="'/event?id=' + this.event.id">
    <div class="card__image-wrapper" v-if="this.event.img_url">
      <img class="card__image" :src="this.event.img_url" />
    </div>
    <p class="card__description">{{ this.event.desc }}</p>
    <div class="card__id">ポストID : {{ this.event.id }}</div>
    <div class="card__id">投稿者ID : {{ this.event.user_id }}</div>
  </a>
</template>
<script>
export default {
  name: "Postcard",
  data() {
    return {};
  },
  props: {
    event: Object,
    glass: { type: Boolean, default: false }
  },
  computed: {
    classObject() {
      return {
        "card--glass": this.glass,
      };
    },
  },
};
</script>
<style scoped lang="scss">
.card {

  $this: &;

  padding: 10px;
  position: relative;
  background-color: #fff;
  color: #3E2649;

  &--glass {
    width: calc(100% - 20px);
    border-radius: 14px;
    backdrop-filter: blur(2px);
    border: 1px solid #EFE1FD;
    background-color: #fbe8ef36;
    z-index: 100;

    &:nth-child(odd) {
      margin: 0 -20px 0 20px;
    }

    &:nth-child(even) {
      margin-right: 0 20px 0 -20px;
    }
  }

  &:nth-child(odd) {
    #{$this}__image-wrapper {
      transform: rotate(2deg);
    }
  }

  &:nth-child(even) {
    #{$this}__image-wrapper {
      transform: rotate(-2deg);
    }
  }

  &__image {
    border: 1px solid #fbe8ef;
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  &__image-wrapper {
    width: 100px;
    height: 140px;
    padding: 6px 6px 20px 6px;
    background-color: #fff;
    border: 1px solid #fbe8ef;
  }

  &__title {
    font-size: 18px;
  }

  &__description {
    margin-top: 4px;
    font-size: 12px;
    height: 20px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }

  &__id {
    font-size: 10px;
    color: #555;
  }
}
</style>
