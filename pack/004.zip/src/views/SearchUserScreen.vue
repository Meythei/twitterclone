<template>
    <div class="search">
        <div class="search__control">
            <input class="search__input" @keypress.enter="searchUser" type="text" placeholder="ユーザー名 / ID" v-model="search_input">
            <button class="search__button" @click="searchUser">
                検索
            </button>
        </div>
        <div class="search__result">
            <ul class="search__result-list result-list" v-if="search_result">
                <Transition v-for="user in search_result" :key="user.id" appear @before-enter="ShowResult_01" @enter="ShowResult_02" @before-leave="HideResult_01">
                    <li class="result-list__item">
                        <router-link :to="'/user/' + user.uid" class="result-list__link">
                            <img :src="user.photoURL" alt="" class="result-list__image" />
                            <div class="result-list__text">
                                <h2 class="result-list__username">{{ user.username }}</h2>
                                <p class="result-list__uid">{{ user.uid }}</p>
                            </div>
                        </router-link>
                    </li>
                </Transition>
            </ul>
            <Transition v-else @enter="ShowError">
                <div class="search__result-msg">
                    検索結果がありません
                </div>
            </Transition>
        </div>
    </div>
</template>

<script>
import { getFirestore, collection, query, getDocs, where } from "firebase/firestore";
import gsap from "gsap";

// 検索結果出現前に実行
function ShowResult_01(el) {
    if (el) {
        el.style.opacity = 0;
        el.style.transform = 'translateX(30px)';
    }
}

// 検索結果出現時に実行
function ShowResult_02(el) {
    if (el) {
        gsap.to(el, {
            opacity: 1,
            x: 0,
            duration: 0.6,
            delay: el.dataset.index * 0.3,
        })
    }
}

function HideResult_01(el) {
    if (el) {
        gsap.to(el, {
            opacity: 0,
            x: 30,
            duration: 0.6,
        })
    }
}

function ShowError() {
    gsap.to(".search__result-msg", {
        opacity: 1,
        y: 0,
        duration: 0.6,
    });

}

export default {
    name: "SearchUserScreen",
    components: {
        // card,
    },
    data() {
        return {
            search_result: [],
            search_input: "",
            isResultShow: false,
        };
    },
    mounted: function () {

        // ------------------------------
        // -´˚｡⋆ GSAP ANIMATION ⋆｡˚´ˎ˗
        // ------------------------------

        // 検索窓表示
        gsap.from(".search__control", {
            y: 50,
            opacity: 0,
            duration: 0.6,
            ease: "power2.out",
        });



    },
    methods: {
        searchUser() {

            const db = getFirestore();

            // AND検索のサンプル
            // 
            // query(
            //     collection(db, "users"),
            //     where("uid", "==", this.search_input),
            //     where("username", "==", this.search_input)
            // )

            const usernameQuery = query(collection(db, "users"), where("username", "==", this.search_input));

            const uidQuery = query(collection(db, "users"), where("uid", "==", this.search_input));

            Promise.all([getDocs(usernameQuery), getDocs(uidQuery)])
                .then((querySnapshots) => {
                    const mergedDocs = [];
                    querySnapshots.forEach((querySnapshot) => {
                        querySnapshot.forEach((doc) => {
                            mergedDocs.push(doc);
                        });
                    });
                    this.search_result = [];
                    mergedDocs.forEach((doc) => {
                        this.search_result.push(doc.data());
                    });
                    this.isResultShow = true;



                })
                .catch((error) => {
                    console.log("ドキュメント取得ミス: ", error);
                });
        },
        ShowResult_01,
        ShowResult_02,
        HideResult_01,
        ShowError
    },
};
</script>

<style lang="scss">
.search {
    position: relative;

    &__control {
        border-radius: 40px;
        border: 1px solid #BD91B9;
        background: #FEFBFF;
        padding: 4px;
        display: flex;
        justify-content: space-between;
    }

    &__input {
        font-size: 18px;
        font-weight: bold;
        padding: 8px;
        border-radius: 20px;

        &:focus {
            background: #BD91B920;
        }
    }

    &__button {
        padding: 8px 24px;
        border-radius: 20px;
        background: #BD91B9;
        color: #FEFBFF;
    }

    &__result {
        margin-top: 20px;
    }

    &__result-list {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    &__result-msg {
        text-align: center;
        transform: translateY(50px);
        opacity: 0;
    }

}

.result-list {

    &__item {}

    &__link {
        display: flex;
        gap: 10px;
        border-radius: 30px;
        padding: 20px;
        background: #FEFBFF;

        &:hover {
            background: #BD91B920;
        }
    }

    &__image {
        width: 40px;
        height: 40px;
        border-radius: 30px;

    }

    &__text {}

    &__username {
        font-size: 18px;
        font-weight: bold;

    }

    &__uid {
        margin-top: 4px;
        font-size: 12px;
        color: #888;
    }
}
</style>