<template>
    <div class="profile">
        <div class="profile__icon">
            <img v-if="userdata.photoURL" :src="userdata.photoURL" alt="" srcset="" class="profile__icon-image">
            <div v-else class="profile__icon-slot"></div>
        </div>
        <div v-if="userdata.username" class="profile__username">
            {{ userdata.username }}
        </div>
        <div v-if="userdata.uid" class="profile__uid">
            {{ userdata.uid }}
        </div>
        <div class="profile__ff">
            <div class="profile__following">
                フォロー中 : {{ followCount }}
            </div>
            <div class="profile__follower">
                フォロワー : {{ followerCount }}
            </div>
        </div>
        <button v-if="followcheck" @click="follow">
            フォローする
        </button>
        <button v-else @click="unfollow">
            フォローを解除する
        </button>
        <img class="profile__figure-cat" :src="figure_cat" alt="">
    </div>
    <div class="cardlist">
        <card class="card" v-for="event in events" :event="event" :key="event.id">
        </card>
    </div>
</template>
<script>
import card from "@/components/Postcard.vue";
import {
    arrayUnion,
    arrayRemove,
    getFirestore,
    collection,
    query,
    doc,
    updateDoc,
    where,
    getDocs,
} from "firebase/firestore";

export default {
    name: "UserpageScreen",
    components: {
        card,
    },
    data() {
        return {
            uid: this.$route.params.uid,
            userdata: [],
            events: [],
            photoURL: this.$store.state.photoURL,
            figure_cat: require("@/assets/img/prop/figure_cat.png"),
        };
    },
    methods: {
        refreshUserdata() {
            const db = getFirestore();

            // ユーザー情報を取得する
            const q_user = query(
                collection(db, "users"),
                where("uid", "==", this.uid)
            );
            getDocs(q_user)
                .then((querySnapshot) => {
                    querySnapshot.forEach((doc) => {
                        this.userdata = doc.data();
                    });
                })
                .catch((error) => {
                    console.log("ユーザー情報取得ミス: ", error);
                });

            console.log(this.userdata)

        },
        refreshPostdata() {
            // ユーザーの投稿情報を取得する
            const db = getFirestore();
            const q = query(
                collection(db, "events"),
                where("user_id", "==", this.uid)
            );
            getDocs(q)
                .then((querySnapshot) => {
                    querySnapshot.forEach((doc) => {
                        this.events.push(doc.data());
                        // doc.idを追加
                        this.events[this.events.length - 1].id = doc.id;
                    });
                })
                .catch((error) => {
                    console.log("ドキュメント取得ミス: ", error);
                });

        },
        async follow() {
            const db = getFirestore();

            try {
                // 自分のusers>uid>followに相手のuidを追加
                const userRef = doc(db, "users", this.$store.state.uid);
                updateDoc(userRef, {
                    follow: arrayUnion(this.userdata.uid)
                });
                // 相手のusers>uid>followerに自分のuidを追加
                const userRef2 = doc(db, "users", this.userdata.uid);
                updateDoc(userRef2, {
                    follower: arrayUnion(this.$store.state.uid)
                });

                console.log("フォローした");
                this.refreshUserdata();

            } catch (error) {
                console.error("フォローエラー: ", error);
            }

        },
        async unfollow() {
            const db = getFirestore();

            try {
                // 自分のusers>uid>followから相手のuidを削除
                const userRef = doc(db, "users", this.$store.state.uid);
                await updateDoc(userRef, {
                    follow: arrayRemove(this.userdata.uid)
                });

                // 相手のusers>uid>followerから自分のuidを削除
                const userRef2 = doc(db, "users", this.userdata.uid);
                await updateDoc(userRef2, {
                    follower: arrayRemove(this.$store.state.uid)
                });

                console.log("フォロー解除した");
                this.refreshUserdata();

            } catch (error) {
                console.error("フォロー解除エラー: ", error);
            }

        }
    },
    mounted: function () {

        if (this.uid === this.$store.state.uid) {
            this.$router.push('/mypage');
        }

        this.refreshUserdata();
        this.refreshPostdata();

    },
    computed: {
        followcheck() {
            let check = true;
            if (this.userdata.follower && this.userdata.follower[0] !== '') {
                this.userdata.follower.forEach((follower) => {
                    if (follower === this.$store.state.uid) {
                        check = false;
                    }
                });
            }
            return check;
        },
        followCount() {
            let count = 0;
            if (this.userdata.follow && this.userdata.follow[0] !== '') {
                count = this.userdata.follow.length;
            }
            return count;
        },
        followerCount() {
            let count = 0;
            if (this.userdata.follower && this.userdata.follower[0] !== '') {
                count = this.userdata.follower.length;
            }
            return count;
        }
    }
};
</script>
<style lang="scss">
.profile {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    padding: 20px 40px;
    border-radius: 26px;
    background-color: #fff;
    border: 1px solid #ddbfec;

    &__icon {
        width: 80px;
        height: 80px;
        object-fit: contain;
        border-radius: 40px;
        overflow: hidden;
    }

    &__icon-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 40px;
        border: 1px solid #ddbfec;
    }

    &__icon-slot {
        width: 100%;
        height: 100%;
        border-radius: 40px;
        border: 1px dashed #ddbfec;
    }

    &__username {
        font-size: 18px;
        font-weight: bold;
    }

    &__uid {
        font-size: 12px;
    }

    &__figure-cat {
        width: 160px;
        height: 160px;
        object-fit: contain;
        position: absolute;
        top: -20px;
        right: -40px;
        animation: rotate 80s linear infinite;
    }

    @keyframes rotate {
        0% {
            transform: rotate(0deg);
        }

        100% {
            transform: rotate(360deg);
        }
    }
}

.cardlist {
    display: flex;
    flex-direction: column;
    gap: 10px;
    overflow: auto hidden;
    padding-bottom: 10px;
}
</style>