<template>
  <div class="vote-event">
    <div class="home">
      <h1>ポスト画面</h1>

      <p>{{ this.events.desc }}</p>
      <img :src="events.img_url" v-if="events.img_url" />
    </div>
  </div>
</template>
<script>
import { doc, getDoc, getFirestore } from "firebase/firestore";

export default {
  name: "PostScreen",
  components: {},
  data() {
    return {
      events: [],
      postData: {
        user_id: null,
      },
      showCommentInput: {},
    };
  },
  async mounted() {
    try {
      this.queryParams = this.$route.query;
      if (!this.queryParams.id) {
        this.$router.push("/error?msg=invalid_id");
      }

      // 'firestoreのeventsからドキュメント名がqueryParams.idのものを取得'
      // '取得したデータをeventに格納'
      const db = getFirestore();
      const docRef = doc(db, "events", this.queryParams.id);
      const docSnapshot = await getDoc(docRef);

      // ドキュメントが存在する場合、データを取得
      if (docSnapshot.exists) {
        this.events = docSnapshot.data();
      } else {
        console.error("ドキュメントが存在しません");
        this.$router.push("/error?msg=event_not_found");
      }
    } catch (error) {
      console.error("データの取得中にエラーが発生しました", error);
    }
    this.postData.user_id = this.$store.state.uid;
  },
  computed: {},
};
</script>
