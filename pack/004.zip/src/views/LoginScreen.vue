<template>
  <div class="login">
    <div class="login__message-area">
      <h1 class="login__heading">ログインしていません</h1>
      <img class="login__image" src="https://placehold.jp/200x150.png" alt="" srcset="" />
    </div>
    <button @click="signInWithGoogle" class="sigin-with-google login__button">
      <img :src="googleLogo" alt="" class="sigin-with-google__image" />
      <div class="sigin-with-google__text">Googleで続行</div>
    </button>
  </div>
</template>

<script>
import { GoogleAuthProvider, signInWithPopup, getAuth } from "firebase/auth";
import {
  getFirestore,
  collection,
  doc,
  updateDoc,
} from "firebase/firestore";
import store from "@/store";

const auth = getAuth();
async function signInWithGoogle() {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    // storeにuidを保存
    store.commit("setProfile", result);

    // firestoreにユーザーデータを更新

    const db = getFirestore();
    console.log("Firestore Database Reference:", db);
    // step1
    const eventCollectionRef = collection(db, "users");
    const eventDocRef = doc(eventCollectionRef, result.user.uid);

    const postdata = {
      uid: result.user.uid,
      username: result.user.displayName,
      email: result.user.email,
      photoURL: result.user.photoURL,
    };

    console.log(postdata);

    // updateDoc メソッドを使用
    await updateDoc(eventDocRef, postdata);

    console.log("ログイン成功 : ", result);
    this.$router.push("/");
  } catch (e) {
    console.log("ログイン失敗 : " + e);
  }
}

export default {
  name: "LoginScreen",
  data() {
    return {
      googleLogo: require("@/assets/img/prop/google.svg"),
    };
  },
  methods: {
    signInWithGoogle, // メソッドをエクスポート
  },
};
</script>

<style lang="scss" scoped>
.login {
  border-radius: 42px;
  overflow: hidden;
  z-index: 100;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 360px;
  background-color: #fff;
  border: 1px solid #ddbfec;
  color: #3e2649;

  &__message-area {
    padding: 24px 20px;
    width: 100%;
    gap: 12px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  &__heading {
    font-size: 24px;
    font-weight: bold;
    text-align: center;
  }

  &__image {}

  &__button {}
}

.sigin-with-google {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px 20px;
  background-color: #fff;
  color: #c370ca;
  width: 100%;
  position: relative;

  &:before {
    content: "";
    position: absolute;
    top: 0;
    left: 50%;
    translate: -50%;
    width: 90%;
    height: 1px;
    background-color: #c370ca;
    transition: 0.5s;
  }

  &:hover {
    background-color: #f7eeff;

    &:before {
      width: 100%;
      transition: 0.5s;
    }
  }

  &__image {
    width: 24px;
    height: 24px;
    margin-right: 8px;
  }

  &__text {
    font-size: 16px;
    font-weight: bold;
  }
}
</style>
