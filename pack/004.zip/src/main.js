import { createApp } from "vue";
import App from "./App.vue";
import store from "./store";
import router from "./router";

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyD9oX9uWgzLfyv6UAtElR6MQ31DmyS_ppc",
  authDomain: "morph-scheme.firebaseapp.com",
  databaseURL:
    "https://morph-scheme-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "morph-scheme",
  storageBucket: "morph-scheme.appspot.com",
  messagingSenderId: "540621217864",
  appId: "1:540621217864:web:b3fb938e94b17fd388b87d",
  measurementId: "G-JQP203Y0W6",
  // envがうまくいかないので一旦ここに書く
  // apiKey: process.env.VUE_APP_APIKEY,
  // authDomain:process.env.VUE_APP_AUTHDOMAIN,
  // databaseURL:process.env.VUE_APP_DATABASEURL,
  // projectId:process.env.VUE_APP_PROJECTID,
  // storageBucket:process.env.VUE_APP_STORAGEBUCKET,
  // messagingSenderId:process.env.VUE_APP_MESSAGINGSENDERID,
  // appId:process.env.VUE_APP_PROJECTID,
  // measurementId:process.env.VUE_APP_MEASUREMENTID
};

const firebaseApp = initializeApp(firebaseConfig);
const storage = getStorage(firebaseApp);
const db = getFirestore(firebaseApp);
console.log(db);

const app = createApp(App);

app.use(router);
app.use(store);
app.mixin({
  methods: {
    async uploadImage(file, path = "") {
      const storageRef = ref(storage, "images/" + path + file.name);
      try {
        const snapshot = await uploadBytes(storageRef, file);
        console.log("ファイル送信成功:", snapshot);

        const downloadURL = await getDownloadURL(storageRef);
        console.log("download URL:", downloadURL);

        return downloadURL;
      } catch (error) {
        console.error("ファイル送信エラー:", error);
        throw error;
      }
    },
  },
});
app.mount("#app");
