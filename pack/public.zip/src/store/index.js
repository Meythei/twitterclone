import { createStore } from "vuex";

export default createStore({
  state: {
    isFirstVisit: true,
    uid: null,
  },
  getters: {},
  mutations: {
    setUid(state, uid) {
      state.uid = uid;
    },
    SET_FIRST_VISIT(state, payload) {
      state.isFirstVisit = payload;
    },
  },
  actions: {
    checkFirstVisit({ commit }) {
      const visitedBefore = localStorage.getItem("visitedBefore");
      if (!visitedBefore) {
        localStorage.setItem("visitedBefore", "true");
      } else {
        commit("SET_FIRST_VISIT", false);
      }
    },
  },
  modules: {},
});
