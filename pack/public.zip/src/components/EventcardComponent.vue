<template>
  <a v-bind:href="'/event?id=' + this.event_id">
    <div class="event-card">
      <slot></slot>
    </div>
  </a>
</template>
<script>
export default {
  name: "EventardComponent",
  data() {
    return {};
  },
  props: {
    event_id: {
      type: String,
      required: true,
    },
  },
};
</script>
<style scoped lang="scss">
.event-card {
  width: 180px;
  padding: 10px;
  position: relative;
}
</style>
