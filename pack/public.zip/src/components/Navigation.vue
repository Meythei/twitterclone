<template>
  <nav class="sidebar">
    <router-link to="/" class="sidebar__button">Home</router-link>
    <div v-if="!$store.state.uid">
      <router-link to="/login" class="sidebar__button">login</router-link>
    </div>
    <template v-else>
      <router-link to="/mypage" class="sidebar__button">Mypage</router-link>
      <button @click="openModal" class="sidebar__button">ポストを作成</button>
    </template>
  </nav>
</template>

<script>
export default {
  name: "CreatePostScreen",
  methods: {
    openModal() {
      this.$emit("openModal");
    },
  },
};
</script>

<style lang="scss" scoped>
.sidebar {
  background-color: #202020;
  padding: 16px;
  position: fixed;
  display: flex;
  align-items: center;
  gap: 6px;
  border-radius: 6px;
  width: calc(100% - 58px);
  bottom: 10px;
  left: 50%;
  translate: -50% 0 0 !important;
  z-index: 100;
  &__button {
    padding: 2px 4px;
    border-radius: 4px;
    background-color: #444;
  }
}
</style>
