<template>
  <a v-bind:href="'/event?id=' + this.event.id">
    <div class="card">
      <img
        class="card__img"
        :src="this.event.img_url"
        v-if="this.event.img_url"
      />
      <p class="card__description">{{ this.event.desc }}</p>
      <div class="card__id">ポストID : {{ this.event.id }}</div>
      <div class="card__id">投稿者ID : {{ this.event.user_id }}</div>
    </div>
  </a>
</template>
<script>
export default {
  name: "Postcard",
  data() {
    return {};
  },
  props: {
    event: Object,
  },
};
</script>
<style scoped lang="scss">
.card {
  padding: 10px;
  position: relative;
  background: #1a1a1a;
  &__img {
    width: 120px;
    height: 120px;
  }
  &__title {
    font-size: 18px;
  }
  &__description {
    margin-top: 4px;
    font-size: 12px;
    height: 20px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
  &__id {
    font-size: 10px;
    color: #555;
  }
}
</style>
