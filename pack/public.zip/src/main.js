import { createApp } from "vue";
import App from "./App.vue";
import store from "./store";
import router from "./router";

import VueDatePicker from "@vuepic/vue-datepicker";
import "@vuepic/vue-datepicker/dist/main.css";

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

const firebaseConfig = {
  // envがうまくいかないので一旦ここに書く
  // apiKey: process.env.VUE_APP_APIKEY,
  // authDomain:process.env.VUE_APP_AUTHDOMAIN,
  // databaseURL:process.env.VUE_APP_DATABASEURL,
  // projectId:process.env.VUE_APP_PROJECTID,
  // storageBucket:process.env.VUE_APP_STORAGEBUCKET,
  // messagingSenderId:process.env.VUE_APP_MESSAGINGSENDERID,
  // appId:process.env.VUE_APP_PROJECTID,
  // measurementId:process.env.VUE_APP_MEASUREMENTID
};

const firebaseApp = initializeApp(firebaseConfig);
const storage = getStorage(firebaseApp);
const db = getFirestore(firebaseApp);
console.log(db);

const app = createApp(App);
app.component("VueDatePicker", VueDatePicker);

app.use(router);
app.use(store);
app.mixin({
  methods: {
    async uploadImage(file, path = "") {
      const storageRef = ref(storage, "images/" + path + file.name);
      try {
        const snapshot = await uploadBytes(storageRef, file);
        console.log("ファイル送信成功:", snapshot);

        const downloadURL = await getDownloadURL(storageRef);
        console.log("download URL:", downloadURL);

        return downloadURL;
      } catch (error) {
        console.error("ファイル送信エラー:", error);
        throw error;
      }
    },
  },
});
app.mount("#app");
