<template>
  <div id="app">
    <div class="home">
      <Navigation @openModal="openModal" />
      <router-view />
      <div v-if="!$store.state.uid">
        <button @click="openModal">ポストを作成</button>
      </div>
      <!-- モーダルが開いている場合にのみ ModalComponent をレンダリング -->
      <PostScreen v-if="isModalOpen" @closeModal="closeModal" />
    </div>
  </div>
</template>
<script>
import Navigation from "@/components/Navigation.vue";
import PostScreen from "@/views/CreatePostScreen.vue";

export default {
  name: "App",
  data() {
    return {
      isModalOpen: false,
    };
  },
  created() {
    // 現在ログインしているかどうかを確認
  },
  components: { PostScreen, Navigation },
  methods: {
    openModal() {
      this.isModalOpen = true;
    },
    closeModal() {
      this.isModalOpen = false;
    },
  },
};
</script>
<style lang="scss">
@import "@/assets/css/reset.css";
#app {
  overflow-x: hidden;
  position: relative;
  min-height: 100vh;
}
.home {
  max-width: 600px;
  margin: 0 auto;
}
</style>
