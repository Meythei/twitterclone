<template>
  <div class="cardlist">
    <card class="card" v-for="event in events" :event="event" :key="event.id">
    </card>
  </div>
  <!-- ポストがない場合 -->
  <div v-if="events.length === 0">ポストがありません</div>
</template>

<script>
import card from "@/components/Postcard.vue";
import { getFirestore, collection, query, getDocs } from "firebase/firestore";

export default {
  name: "DashboardScreen",
  components: {
    card,
  },
  data() {
    return {
      events: [],
    };
  },
  mounted: function () {
    const db = getFirestore();
    const q = query(collection(db, "events"));
    getDocs(q)
      .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          this.events.push(doc.data());
          // doc.idを追加
          this.events[this.events.length - 1].id = doc.id;
        });
      })
      .catch((error) => {
        console.log("ドキュメント取得ミス: ", error);
      });
  },
  methods: {
    formatDate(timestamp) {
      const date = new Date(timestamp.seconds * 1000);
      return date.toLocaleDateString("ja-JP", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      });
    },
  },
};
</script>
