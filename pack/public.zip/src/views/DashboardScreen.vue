<template>
  <div class="cardlist">
    <card
      class="card"
      v-for="event in events"
      :event_id="event.id"
      :key="event.id"
    >
      <img class="card-img" :src="event.img_url" v-if="event.img_url" />
      <div class="card-description">{{ event.desc }}</div>
      <div class="card-id">{{ event.id }}</div>
    </card>
  </div>
  <!-- ポストがない場合 -->
  <div v-if="events.length === 0">ポストがありません</div>
</template>

<script>
import card from "@/components/EventcardComponent.vue";
import {
  getFirestore,
  collection,
  query,
  // where,
  getDocs,
} from "firebase/firestore";

export default {
  name: "DashboardScreen",
  components: {
    card,
  },
  data() {
    return {
      events: [],
    };
  },
  mounted: function () {
    const db = getFirestore();
    const q = query(
      collection(db, "events")
      // where("user_id", "==", this.$store.state.uid)
    );
    getDocs(q)
      .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          this.events.push(doc.data());
          // doc.idを追加
          this.events[this.events.length - 1].id = doc.id;
        });
      })
      .catch((error) => {
        console.log("ドキュメント取得ミス: ", error);
      });
  },
  methods: {
    formatDate(timestamp) {
      const date = new Date(timestamp.seconds * 1000);
      return date.toLocaleDateString("ja-JP", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      });
    },
  },
};
</script>
<style lang="scss">
.card {
  background: #1a1a1a;
}
.cardlist {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-left: 13px;
  overflow: auto hidden;
  padding-bottom: 10px;
}
.card-img {
  width: 120px;
  height: 120px;
}
.card-title {
  font-size: 18px;
}
.card-description {
  margin-top: 4px;
  font-size: 12px;
  height: 20px;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}
.card-id {
  font-size: 10px;
  color: #555;
}
</style>
