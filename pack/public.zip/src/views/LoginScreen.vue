<template>
  <div class="Login">
    <div class="err_msg">ERR : not logged in user</div>
    <h1>ログアウトしました</h1>
    <button @click="signInWithGoogle" class="c-button">ログインする</button>
    <!-- <img
      :src="require('@/assets/img/Looper.png')"
      alt="google"
      class="looper"
    /> -->
  </div>
</template>

<script>
import { GoogleAuthProvider, signInWithRedirect, getAuth } from "firebase/auth";
import { useRouter } from "vue-router";
import store from "../store";

const router = useRouter();
const auth = getAuth();
function signInWithGoogle() {
  const provider = new GoogleAuthProvider();
  signInWithRedirect(auth, provider)
    .then((result) => {
      // storeにuidを保存
      store.commit("setUid", result.user.uid);
      router.push("/login");
    })
    .catch((e) => {
      console.log(e);
    });
}

export default {
  name: "LoginScreen",
  components: {},
  methods: {
    signInWithGoogle, // メソッドをエクスポート
  },
};
</script>
<style lang="scss" scoped>
.c-button {
  display: inline-block;
  background: #fff;
  color: #000;
  padding: 4px 12px;
}
.looper {
  position: absolute;
  bottom: -60px;
  left: 50%;
  translate: -50% 0 0 !important;
}
</style>
