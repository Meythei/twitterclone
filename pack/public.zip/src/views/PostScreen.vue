<template>
  <div class="vote-event">
    <div class="home">
      <h1>ポスト画面</h1>

      <div>{{ this.events.title }}</div>
      <div>{{ this.events.desc }}</div>
      <img :src="events.img_url" v-if="events.img_url" />
    </div>
  </div>
</template>
<script>
import { doc, getDoc, setDoc, getFirestore } from "firebase/firestore";

export default {
  name: "PostScreen",
  components: {},
  data() {
    return {
      events: [],
      postData: {
        user_id: null,
        vote_map: [],
      },
      showCommentInput: {},
      adminmenu: false,
    };
  },
  async mounted() {
    try {
      this.queryParams = this.$route.query;
      if (!this.queryParams.id) {
        this.$router.push("/error?msg=invalid_id");
      }

      // 'firestoreのeventsからドキュメント名がqueryParams.idのものを取得'
      // '取得したデータをeventに格納'
      const db = getFirestore();
      const docRef = doc(db, "events", this.queryParams.id);
      const docSnapshot = await getDoc(docRef);

      // ドキュメントが存在する場合、データを取得
      if (docSnapshot.exists) {
        this.events = docSnapshot.data();
      } else {
        console.error("ドキュメントが存在しません");
        this.$router.push("/error?msg=event_not_found");
      }
    } catch (error) {
      console.error("データの取得中にエラーが発生しました", error);
    }
    this.postData.user_id = this.$store.state.uid;
    this.postData.vote_map = this.events.scheduleList.map((schedule) => ({
      date: schedule,
      desc: "",
      level: "0",
    }));
    if (this.events.user_id === this.$store.state.uid) {
      this.adminmenu = true;
    }
  },
  methods: {
    // 渡されたvote_data(配列)の中身から、targetDateが一致するものを返す
    // 一致するものがない場合はnullを返す
    userVoteData(targetDate, userVoteData) {
      return userVoteData.vote_map.find((data) => data.date === targetDate);
    },
    async vote() {
      console.log(this.postdata);
      const db = getFirestore();
      const docRef = doc(db, "events", this.queryParams.id);
      const docSnapshot = await getDoc(docRef);

      if (docSnapshot.exists) {
        const voteData = docSnapshot.data().vote_data || [];
        const userVoteIndex = voteData.findIndex(
          (data) => data.user_id === this.postData.user_id
        );
        if (userVoteIndex !== -1) {
          voteData[userVoteIndex] = this.postData;
        } else {
          voteData.push(this.postData);
        }
        await setDoc(docRef, { vote_data: voteData }, { merge: true });
      } else {
        await setDoc(docRef, { vote_data: [this.postData] });
      }
    },
    voteCountsForSchedule(schedule) {
      let counts = { level0: 0, level1: 0, level2: 0 };
      for (let vote of this.events.vote_data) {
        const Votelevel = this.userVoteData(schedule, vote).level;
        console.log(Votelevel);
        if (Votelevel == "0") counts.level0++;
        else if (Votelevel == "1") counts.level1++;
        else if (Votelevel == "2") counts.level2++;
      }
      return counts;
    },
  },
  computed: {},
};
</script>
