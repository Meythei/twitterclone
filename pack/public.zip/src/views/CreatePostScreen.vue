<template>
  <div class="create-post">
    <h1>ポストを作成する</h1>

    <!-- 送信ボタン -->
    <textarea v-model="description" placeholder="いまなにしてる？"></textarea>
    <input type="file" @change="onChangeImage" />
    <img v-if="img_url" :src="img_url" />
    <button @click="createEvent">送信</button>
    {{ storagePath }}
  </div>
  <div class="modal-background" @click="close"></div>
</template>

<script>
import { ref } from "vue";
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  updateDoc,
} from "firebase/firestore";

const date = ref(new Date());
export default {
  name: "CreatePostScreen",
  data() {
    return {
      uid: this.$store.state.uid,
      description: "",
      img_url: "",
      storagePath: "",
      file: null,
    };
  },
  setup() {
    const title = ref("");
    return {
      title,
      date,
    };
  },
  methods: {
    onChangeImage(e) {
      const files = e.target.files;
      if (files.length > 0) {
        this.file = files[0];
        this.img_url = URL.createObjectURL(files[0]);
      }
    },
    async createEvent() {
      const db = getFirestore();
      console.log("Firestore Database Reference:", db);

      // step1
      const eventCollectionRef = collection(db, "events");
      const eventDocRef = doc(eventCollectionRef);
      // データ構造
      const event = {
        user_id: this.uid,
        desc: this.description,
      };

      console.log(event);

      // setDoc メソッドを使用
      await setDoc(eventDocRef, event);

      // step2
      const eventId = eventDocRef.id;

      // step3
      if (this.file) {
        this.storagePath = await this.uploadImage(
          this.file,
          "event/" + eventId + "/"
        );
      }

      // step4
      await updateDoc(eventDocRef, {
        img_url: this.storagePath,
      });

      alert("投稿を作成しました:" + this.uid);
      // VueDatePickerをクリア
      this.date = null;

      this.$router.push("/");
    },
    close() {
      this.$emit("close");
    },
  },
};
</script>

<style lang="scss" scoped>
.modal-background {
  z-index: 100;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 100;
}
.create-post {
  z-index: 1000;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: #000;
  padding: 20px;
  border-radius: 10px;
}
</style>
