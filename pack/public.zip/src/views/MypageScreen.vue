<template>
  <div class="profile">
    <h1 class="profile__heading">マイページ</h1>
    <div v-if="$store.state.uid" class="profile__username">
      ユーザーID : {{ $store.state.uid }}
    </div>
  </div>
  <div class="cardlist">
    <card class="card" v-for="event in events" :event="event" :key="event.id">
    </card>
  </div>
</template>
<script>
import card from "@/components/Postcard.vue";
import {
  getFirestore,
  collection,
  query,
  where,
  getDocs,
} from "firebase/firestore";

export default {
  name: "DashboardScreen",
  components: {
    card,
  },
  data() {
    return {
      events: [],
    };
  },
  mounted: function () {
    const db = getFirestore();
    const q = query(
      collection(db, "events"),
      where("user_id", "==", this.$store.state.uid)
    );
    getDocs(q)
      .then((querySnapshot) => {
        querySnapshot.forEach((doc) => {
          this.events.push(doc.data());
          // doc.idを追加
          this.events[this.events.length - 1].id = doc.id;
        });
      })
      .catch((error) => {
        console.log("ドキュメント取得ミス: ", error);
      });
  },
};
</script>
<style lang="scss">
.profile {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 20px;
  &__heading {
    font-size: 24px;
  }
  &__username {
    font-size: 18px;
  }
}
.cardlist {
  display: flex;
  flex-direction: column;
  gap: 10px;
  overflow: auto hidden;
  padding-bottom: 10px;
}
</style>
