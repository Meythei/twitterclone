import { createRouter, createWebHistory } from "vue-router";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import store from "../store";
const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      meta: { requiresAuth: true },
      component: () => import("../views/DashboardScreen.vue"),
    },
    { path: "/login", component: () => import("../views/LoginScreen.vue") },
    {
      path: "/create-post",
      component: () => import("../views/CreatePostScreen.vue"),
      meta: { requiresAuth: true },
    },
    {
      path: "/event",
      component: () => import("../views/PostScreen.vue"),
      meta: { requiresAuth: true },
    },
    {
      path: "/Mypage",
      component: () => import("../views/MypageScreen.vue"),
      meta: { requiresAuth: true },
    },
    {
      path: "/user/:uid",
      component: () => import("../views/UserpageScreen.vue"),
      meta: { requiresAuth: true },
    },
    {
      path: "/search",
      component: () => import("../views/SearchUserScreen.vue"),
      meta: { requiresAuth: true },
    },
    {
      path: "/error",
      component: () => import("../views/ErrorScreen.vue"),
    },
  ],
});

// 認証していない場合はログイン画面にリダイレクト
router.beforeEach(async (to, from, next) => {
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    const auth = getAuth();

    // onAuthStateChangedの結果を待つPromise
    const authStateChangedPromise = new Promise((resolve) => {
      onAuthStateChanged(auth, (user) => {
        resolve(user);
      });
    });

    // 結果を待つ
    const user = await authStateChangedPromise;

    if (user) {
      // 認証が完了したら
      store.commit("setProfile", user);

      next();
    } else {
      // 認証されていない場合はログインページにリダイレクト
      console.log("ログインしていない");
      next("/login");
    }
  } else {
    // requiresAuthメタが設定されていない場合はそのまま進む
    console.log("ログイン不要");
    next();
  }
});

export default router;
