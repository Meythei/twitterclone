<template>
  <button
    class="c-button"
    :style="{ 'background-color': back_color, color: fore_color }"
  >
    <slot>ボタン</slot>
  </button>
</template>
<script>
export default {
  props: {
    back_color: {
      type: String,
      default: "#00a656",
    },
    fore_color: {
      type: String,
      default: "#ffffff",
    },
  },
};
</script>
<style scoped lang="scss">
.c-button {
}
</style>
