<template>
    <div class="toy-picture" :style="{ transform: 'rotate(' + this.tilt + 'deg)' }">
        <img class="toy-picture__content" :src="this.img_url" />
    </div>
</template>
<script>
export default {
    name: "toy-picture",
    data() {
        return {};
    },
    props: {
        img_url: String,
        tilt: { type: Number, default: 0 },
    },
};
</script>

<style scoped lang="scss">
.toy-picture {
    width: 100px;
    height: 140px;
    padding: 6px 6px 20px 6px;
    background-color: #fff;
    border: 1px solid #fbe8ef;

    &__content {
        border: 1px solid #fbe8ef;
        width: 100%;
        height: 100%;
        object-fit: contain;
    }

}
</style>
