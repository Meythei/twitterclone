<template>
  <nav class="sidebar">
    <router-link to="/" class="sidebar__item ">
      <img :src="home" alt="" class="sidebar-button__image" />
      <div class="sidebar-button__text">ホーム</div>
    </router-link>
    <div v-if="!$store.state.uid">
      <router-link to="/login" class="sidebar__item sidebar-button">
        <img :src="signin" alt="" class="sidebar-button__image" />
        <div class="sidebar-button__text">ログイン</div>
      </router-link>
    </div>
    <template v-else>
      <router-link to="/mypage" class="sidebar__item">
        <img :src="mypage" alt="" class="sidebar-button__image" />
        <div class="sidebar-button__text">マイページ</div>
      </router-link>
      <button @click="openModal" class="sidebar__item">
        <img :src="create_post" alt="" class="sidebar-button__image" />
        <div class="sidebar-button__text">ポストを作成</div>
      </button>
      <router-link to="/search" class="sidebar__item">
        <img :src="search" alt="" class="sidebar-button__image" />
        <div class="sidebar-button__text">ユーザー検索</div>
      </router-link>
      <button @click="logout" class="sidebar__item">
        <img :src="signout" alt="" class="sidebar-button__image" />
        <div class="sidebar-button__text">ログアウト</div>
      </button>
    </template>
  </nav>
</template>

<script>
import { getAuth, signOut } from "firebase/auth";
import store from "@/store";

function logout() {
  const auth = getAuth();
  signOut(auth)
    .then(() => {
      store.commit("setProfile", null);
      this.$router.push("/login");
    })
    .catch((e) => {
      console.log("ログアウト失敗: ", e);
      this.$router.push("/");
    });
}

export default {
  name: "CreatePostScreen",
  data() {
    return {
      home: require("@/assets/img/prop/home.webp"),
      signin: require("@/assets/img/prop/login.webp"),
      mypage: require("@/assets/img/prop/mypage.webp"),
      create_post: require("@/assets/img/prop/create_post.webp"),
      signout: require("@/assets/img/prop/logout.webp"),
      search: require("@/assets/img/prop/search.webp"),
    };
  },
  methods: {
    logout,
    openModal() {
      this.$emit("openModal");
    },
  },
};
</script>

<style lang="scss" scoped>
.sidebar {
  padding: 16px;
  border-radius: 42px;
  z-index: 100;
  position: fixed;
  top: 50%;
  left: calc(50% - 500px);
  transform: translate(-50%, -50%);
  display: flex;
  gap: 12px;
  max-width: 300px;
  flex-direction: column;
  background-color: #fff;
  border: 1px solid #ddbfec;
  color: #3e2649;
  font-size: 16px;

  &__item {
    padding: 2px 16px;
    border-radius: 200px;
    width: 200px;
    height: 60px;
    display: flex;
    gap: 10px;
    justify-content: flex-start;
    align-items: center;
    transition: 0.5s;

    &:hover {
      background-color: #f7eeff;
      transition: 0.5s;
    }
  }
}
</style>
