<template>
  <div class="create-post" :class="classObject">
    <!-- 送信ボタン -->
    <textarea class="create-post__textarea" v-model="description" placeholder="いまなにしてる？"></textarea>
    <div class="create-post__mediabar">
      <button class="create-post__mediafile" @click="selectImagefile">
        <img :src="media_input" alt="" />
      </button>
    </div>
    <ToyPicture v-if="img_url" :img_url="img_url" :tilt="2" />
    <button class="create-post__submit" @click="createEvent">
      <img class="create-post__submit-figure" :src="submiticon" alt="" />
    </button>
    {{ storagePath }}
  </div>
  <div class="modal-background" @click="closeModal" :class="classObject"></div>
</template>

<script>
import ToyPicture from "@/components/ToyPicture.vue";
import { ref } from "vue";
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  updateDoc,
} from "firebase/firestore";

export default {
  name: "CreatePostScreen",
  props: {
    isModalOpen: Boolean,
  },
  data() {
    return {
      uid: this.$store.state.uid,
      description: "",
      img_url: "",
      storagePath: "",
      file: null,
      submiticon: require("@/assets/img/prop/submit_p.webp"),
      media_input: require("@/assets/img/prop/media_input_p.webp"),

    };
  },
  setup() {
    const title = ref("");
    return {
      title,
    };
  },
  components: {
    ToyPicture,
  },
  methods: {
    selectImagefile() {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = (e) => {
        this.onChangeImage(e);
      };
      input.click();
    },
    onChangeImage(e) {
      const files = e.target.files;
      if (files.length > 0) {
        this.file = files[0];
        this.img_url = URL.createObjectURL(files[0]);
      }
    },
    async createEvent() {
      const db = getFirestore();
      console.log("Firestore Database Reference:", db);

      // step1
      const eventCollectionRef = collection(db, "events");
      const eventDocRef = doc(eventCollectionRef);
      // データ構造
      const event = {
        user_id: this.uid,
        desc: this.description,
      };

      console.log(event);

      // setDoc メソッドを使用
      await setDoc(eventDocRef, event);

      // step2
      const eventId = eventDocRef.id;

      // step3
      if (this.file) {
        this.storagePath = await this.uploadImage(
          this.file,
          "event/" + eventId + "/"
        );
      }

      // step4
      await updateDoc(eventDocRef, {
        img_url: this.storagePath,
      });

      alert("投稿を作成しました:" + this.uid);

      this.$router.push("/");
    },
    closeModal() {
      this.$emit("closeModal");
    },
  },
  computed: {
    classObject() {
      return {
        "modal-open": this.isModalOpen,
      };
    },
  },
};
</script>

<style lang="scss" scoped>
.modal-background {

  z-index: 100;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #6666;
  backdrop-filter: blur(4px);
  z-index: -1;
  opacity: 0;
  transition: 0.5s;

  &.modal-open {
    z-index: 999;
    opacity: 1;
  }
}

.create-post {
  $this: &;

  z-index: 1000;
  position: absolute;
  top: 50%;
  top: calc(110vh + 100%);
  left: 50%;
  width: calc(100% - 20px);
  transform: translate(-50%, -50%);
  background-color: #fff;
  padding: 40px;
  border-radius: 40px;
  border: 1px solid #c370ca;
  transition: top 0.6s cubic-bezier(0.25, 1, 0.5, 1);

  display: flex;
  flex-direction: column;
  align-items: center;

  &.modal-open {
    top: 50%;
    transition: top 0.6s cubic-bezier(0.25, 1, 0.5, 1);
  }

  &:after {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(calc(-50% + 10px), calc(-50% + 10px));
    content: "";
    width: 100%;
    height: 100%;
    border-radius: 40px;
    background-color: #fff6;
    border: 1px solid #c370ca;
    z-index: -1;
  }

  &__textarea {
    resize: none;
    width: 100%;
    height: 140px;
    margin-bottom: 12px;
    padding-bottom: 12px;
    border-bottom: 1px solid #c370ca;
  }

  &__mediabar {
    width: 100%;
    display: flex;
    justify-content: flex-start;
    gap: 20px;
  }

  &__mediafile {
    width: 40px;
    height: 40px;
    display: flex;
    border-radius: 30px;
    justify-content: center;
    align-items: center;

    &:hover {
      background-color: #c370ca66;
    }

  }

  &__preview {}

  &__submit {
    width: 60px;
    height: 60px;
    margin-top: 12px;
    display: flex;
    border-radius: 60px;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    position: relative;

    &:after {
      position: absolute;
      content: "";
      width: 100%;
      height: 100%;
      border-radius: 40px;
      border: 2px dashed #c370ca;
      animation: rotate 80s linear infinite;
    }

    &:hover {
      #{$this}__submit-figure {
        animation: launch 3s ease-in-out;
      }
    }
  }

  &__submit-figure {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 24px;
    height: 24px;
  }
}

// 回転するアニメーション
@keyframes rotate {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }

}

// 飛行機が飛び立つアニメーション
@keyframes launch {
  0% {
    top: 50%;
  }

  15% {
    top: 60%;
  }

  70% {
    top: -100%;

  }

  70.1% {
    top: 100%;

  }

  100% {
    top: 50%;
  }

}
</style>
