<template>
  <div>ERROR!!</div>
  <div>MSG : {{ this.msg }}</div>
</template>
<script>
export default {
  name: "PostScreen",
  components: {},
  data() {
    return {
      msg: "",
    };
  },
  mounted() {
    this.queryParams = this.$route.query;
    if (this.queryParams.msg) {
      this.msg = this.queryParams.msg;
    }
  },
  methods: {},
};
</script>
