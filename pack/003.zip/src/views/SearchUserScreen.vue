<template>
    <div class="search">
        <h1 class="search__heading">検索</h1>
        <input class="search__heading" type="text" placeholder="ユーザー名" v-model="search_input">
        <button class="search__button" @click="searchUser">
            検索
        </button>
        <div class="search__result-wrapper">
            <ul class="search__result-list result-list" v-if="!search_result.length == 0">
                <li v-for="user in search_result" :key="user.id" class="result-list__item">
                    <router-link :to="'/user/' + user.uid" class="result-list__link">
                        <img :src="user.photoURL" alt="" class="result-list__image" />
                        <div class="result-list__text">
                            <h2 class="result-list__username">{{ user.username }}</h2>
                            <p class="result-list__email">{{ user.email }}</p>
                        </div>
                    </router-link>
                </li>
            </ul>
            <div class="search__result" v-else>
                検索結果がありません
            </div>
        </div>
    </div>
</template>

<script>
import { getFirestore, collection, query, getDocs, where } from "firebase/firestore";


export default {
    name: "SearchUserScreen",
    components: {
        // card,
    },
    data() {
        return {
            search_result: [],
            search_input: "",
        };
    },
    mounted: function () {
        // ------------------------------
        // Firebase
        // ------------------------------
        const db = getFirestore();
        const q = query(collection(db, "users"));
        getDocs(q)
            .then((querySnapshot) => {
                querySnapshot.forEach((doc) => {
                    this.events.push(doc.data());
                });
            })
            .catch((error) => {
                console.log("ドキュメント取得ミス: ", error);
            });


    },
    methods: {
        searchUser() {

            const db = getFirestore();


            // AND検索のサンプル
            // 
            // query(
            //     collection(db, "users"),
            //     where("uid", "==", this.search_input),
            //     where("username", "==", this.search_input)
            // )

            const usernameQuery = query(collection(db, "users"), where("username", "==", this.search_input));

            const uidQuery = query(collection(db, "users"), where("uid", "==", this.search_input));

            Promise.all([getDocs(usernameQuery), getDocs(uidQuery)])
                .then((querySnapshots) => {
                    const mergedDocs = [];
                    querySnapshots.forEach((querySnapshot) => {
                        querySnapshot.forEach((doc) => {
                            mergedDocs.push(doc);
                        });
                    });
                    mergedDocs.forEach((doc) => {
                        this.search_result.push(doc.data());
                    });
                })
                .catch((error) => {
                    console.log("ドキュメント取得ミス: ", error);
                });
        },
    },
};
</script>

<style lang="scss">
.search {
    position: relative;
    border-radius: 40px;
    border: 1px solid #BD91B9;
    background: #FEFBFF;
    padding: 4px;
}
</style>