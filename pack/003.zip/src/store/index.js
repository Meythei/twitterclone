import { createStore } from "vuex";

export default createStore({
  state: {
    uid: null,
    username: null,
    photoURL: null,
  },
  getters: {},
  mutations: {
    setProfile(state, user) {
      if (user) {
        console.log("stateを更新");
        state.uid = user.uid;
        state.username = user.displayName;
        state.photoURL = user.photoURL;
      } else {
        console.log("stateを削除");
        state.uid = null;
        state.username = null;
        state.photoURL = null;
      }
    },
  },
  actions: {},
  modules: {},
});
