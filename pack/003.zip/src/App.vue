<template>
  <div id="app" class="app">
    <Navigation @openModal="openModal" />
    <div class="home">
      <router-view />
      <PostScreen @closeModal="closeModal" :isModalOpen="isModalOpen" />
    </div>
  </div>
</template>
<script>
import Navigation from "@/components/Navigation.vue";
import PostScreen from "@/views/CreatePostScreen.vue";

export default {
  name: "App",
  data() {
    return {
      isModalOpen: false,
    };
  },
  created() {
    // 現在ログインしているかどうかを確認
  },
  components: { PostScreen, Navigation },
  methods: {
    openModal() {
      this.isModalOpen = true;
    },
    closeModal() {
      this.isModalOpen = false;
    },
  },
};
</script>
<style lang="scss">
@import "@/assets/css/reset.css";

.app {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  overflow: hidden;
  min-height: 100vh;
  background: linear-gradient(180deg, #FBECED 0%, #FCDAF7 100%);
}

.home {
  position: relative;
  width: 400px;
}

.create-post-button {
  position: fixed;
  bottom: 20px;
  right: 20px;

  &__button {
    padding: 8px 16px;
    border-radius: 8px;
    background-color: #444;
    color: #fff;
  }
}
</style>
